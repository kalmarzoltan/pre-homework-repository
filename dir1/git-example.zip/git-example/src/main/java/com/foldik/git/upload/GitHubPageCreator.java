package com.foldik.git.upload;

public interface GitHubPageCreator {


    String create(UploadData uploadData);
}
